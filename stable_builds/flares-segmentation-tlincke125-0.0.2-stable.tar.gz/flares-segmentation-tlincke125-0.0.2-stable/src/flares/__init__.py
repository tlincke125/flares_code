"""
.. include::README.md
"""
__docformat__ = "numpy"
